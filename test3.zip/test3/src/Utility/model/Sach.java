
package Utility.model;


public class Sach {
    private String maSach;
    private String tenSach;
    private String NXB;
    private double gia;

    public Sach() {
    }

    public Sach(String maSach, String tenSach, String NXB, double gia) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.NXB = NXB;
        this.gia = gia;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public String getNXB() {
        return NXB;
    }

    public void setNXB(String NXB) {
        this.NXB = NXB;
    }

    public double getGia() {
        return gia;
    }

    public void setGia(double gia) {
        this.gia = gia;
    }
    
}
