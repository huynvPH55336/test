package Utility.Service;

import Utility.DBcontext;
import java.util.ArrayList;
import Utility.model.Sach;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SachService {

    public ArrayList<Sach> getAll() {
        ArrayList<Sach> lstSach = new ArrayList<>();
        String sql = "select Masach,TenSach,NXB,Giatien\n"
                + "From [dbo].[SACH]";
        try {
            Connection cn = DBcontext.getConnection();
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Sach sh = new Sach();
                sh.setMaSach(rs.getString(1));
                sh.setTenSach(rs.getString(2));
                sh.setNXB(rs.getString(3));
                sh.setGia(rs.getDouble(4));
                lstSach.add(sh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lstSach;
    }

    public int add(Sach sh) {
        int row = 0;
        String sql = "insert SACH(Masach,TenSach,NXB,Giatien)\n"
                + "values(?,?,?,?)";
        try {
            Connection cn = DBcontext.getConnection();
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, sh.getMaSach());
            ps.setString(2, sh.getTenSach());
            ps.setString(3, sh.getNXB());
            ps.setDouble(4, sh.getGia());
            row = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
}
